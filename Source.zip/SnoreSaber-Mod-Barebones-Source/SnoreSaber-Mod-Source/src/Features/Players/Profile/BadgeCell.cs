using BeatSaberMarkupLanguage.Attributes;
using HMUI;
using SnoreSaber.Core;
using SnoreSaber.Core.Presentation;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using UnityEngine;

namespace SnoreSaber.Features.Players.Profile {
    internal class BadgeCell : INotifyPropertyChanged, IDisposable {

        [UIComponent("image")]
        protected readonly ImageView _image = null;

        private readonly Sprite _blankSprite = BeatSaberMarkupLanguage.Utilities.ImageResources.BlankSprite;
        private RemoteImageService _remoteImageService;
        private CancellationTokenSource _imageCancellation;
        private string _hoverHint = "";
        [UIValue("hover-hint")]
        protected string hoverHint {
            get => _hoverHint;
            set {
                _hoverHint = value;
                NotifyPropertyChanged();
            }
        }

        internal void Initialize(RemoteImageService remoteImageService) {
            _remoteImageService = remoteImageService;
        }

        public void SetData(string imageURL, string hoverHintText) {
            _imageCancellation?.Cancel();
            _imageCancellation?.Dispose();
            _imageCancellation = new CancellationTokenSource();
            hoverHint = hoverHintText;
            if (_image != null) {
                _image.sprite = _blankSprite;
            }

            if (_remoteImageService == null || string.IsNullOrWhiteSpace(imageURL)) {
                return;
            }

            _remoteImageService.LoadSprite(
                SnoreSaberEndpoints.ResolveImageUrl(imageURL),
                sprite => {
                    if (_imageCancellation != null && !_imageCancellation.IsCancellationRequested && _image != null) {
                        _image.sprite = sprite;
                    }
                },
                error => Plugin.Log.Warn($"Failed to load SnoreSaber badge image '{imageURL}': {error}"),
                _imageCancellation.Token);
        }

        public void SetActive(bool value) {
            if (_image != null) {
                _image.gameObject.SetActive(value);
            }
        }

        public void Dispose() {
            _imageCancellation?.Cancel();
            _imageCancellation?.Dispose();
            _imageCancellation = null;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged([CallerMemberName] string propertyName = "") {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
