





#region Designer generated code
#pragma warning disable CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
namespace SnoreSaber.Live.V1
{

    [global::ProtoBuf.ProtoContract()]
    public partial class ConnectRequest : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"auth_token")]
        [global::System.ComponentModel.DefaultValue("")]
        public string AuthToken { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"session_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string SessionId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"session_key")]
        [global::System.ComponentModel.DefaultValue("")]
        public string SessionKey { get; set; } = "";

        [global::ProtoBuf.ProtoMember(4, Name = @"tournament_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string TournamentId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(5, Name = @"player_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PlayerId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(6, Name = @"platform")]
        public LivePlayerPlatform Platform { get; set; }

        [global::ProtoBuf.ProtoMember(7, Name = @"client_type")]
        public LudusClientType ClientType { get; set; }

        [global::ProtoBuf.ProtoMember(8, Name = @"game_version")]
        [global::System.ComponentModel.DefaultValue("")]
        public string GameVersion { get; set; } = "";

        [global::ProtoBuf.ProtoMember(9, Name = @"client_version")]
        [global::System.ComponentModel.DefaultValue("")]
        public string ClientVersion { get; set; } = "";

        [global::ProtoBuf.ProtoMember(10, Name = @"mods")]
        public global::System.Collections.Generic.List<LiveMod> Mods { get; set; } = new global::System.Collections.Generic.List<LiveMod>();

        [global::ProtoBuf.ProtoMember(11, Name = @"role_names")]
        public global::System.Collections.Generic.List<string> RoleNames { get; set; } = new global::System.Collections.Generic.List<string>();

        [global::ProtoBuf.ProtoMember(12, Name = @"initial_room_context")]
        public LudusRoomContextType InitialRoomContext { get; set; }

        [global::ProtoBuf.ProtoMember(13, Name = @"public_live_presence_opt_out")]
        public bool PublicLivePresenceOptOut { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ConnectAccepted : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"connection_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string ConnectionId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"tournament_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string TournamentId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"protocol_version")]
        public uint ProtocolVersion { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"heartbeat_interval_ms")]
        public uint HeartbeatIntervalMs { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"send_queue_size")]
        public uint SendQueueSize { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"max_packet_size_bytes")]
        public uint MaxPacketSizeBytes { get; set; }

        [global::ProtoBuf.ProtoMember(7, Name = @"room_context")]
        public LudusRoomContextType RoomContext { get; set; }

        [global::ProtoBuf.ProtoMember(8, Name = @"current_match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string CurrentMatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(9, Name = @"client_type")]
        public LudusClientType ClientType { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class SetClientTypeRequest : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"client_type")]
        public LudusClientType ClientType { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReconnectRequested : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"websocket_url")]
        [global::System.ComponentModel.DefaultValue("")]
        public string WebsocketUrl { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"reason")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Reason { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"retry_after_ms")]
        public uint RetryAfterMs { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class Heartbeat : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"last_received_sequence")]
        public ulong LastReceivedSequence { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class HeartbeatAck : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"highest_seen_sequence")]
        public ulong HighestSeenSequence { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ErrorResponse : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"code")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Code { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"message")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Message { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"retryable")]
        public bool Retryable { get; set; }

    }

}

#pragma warning restore CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
#endregion
