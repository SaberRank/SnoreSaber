





#region Designer generated code
#pragma warning disable CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
namespace SnoreSaber.Live.V1
{

    [global::ProtoBuf.ProtoContract()]
    public partial class PresenceUpdate : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"play_state")]
        public LudusPlayState PlayState { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"download_state")]
        public LudusDownloadState DownloadState { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"mods")]
        public global::System.Collections.Generic.List<LiveMod> Mods { get; set; } = new global::System.Collections.Generic.List<LiveMod>();

        [global::ProtoBuf.ProtoMember(4, Name = @"current_room_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string CurrentRoomId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(5, Name = @"current_map_hash")]
        [global::System.ComponentModel.DefaultValue("")]
        public string CurrentMapHash { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class DownloadStateUpdate : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"download_state")]
        public LudusDownloadState DownloadState { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"error_message")]
        [global::System.ComponentModel.DefaultValue("")]
        public string ErrorMessage { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReadyStateUpdate : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"ready_state")]
        public LudusReadyState ReadyState { get; set; }

    }

}

#pragma warning restore CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
#endregion
