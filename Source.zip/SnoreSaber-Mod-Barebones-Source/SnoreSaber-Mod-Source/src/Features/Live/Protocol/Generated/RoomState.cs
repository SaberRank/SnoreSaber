





#region Designer generated code
#pragma warning disable CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
namespace SnoreSaber.Live.V1
{

    [global::ProtoBuf.ProtoContract()]
    public partial class RoomSnapshot : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"rooms")]
        public global::System.Collections.Generic.List<LiveMatchRoomState> Rooms { get; set; } = new global::System.Collections.Generic.List<LiveMatchRoomState>();

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class LiveMatchRoomState : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"room_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string RoomId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"loaded_song")]
        public bool LoadedSong { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"loaded_song_hash")]
        [global::System.ComponentModel.DefaultValue("")]
        public string LoadedSongHash { get; set; } = "";

        [global::ProtoBuf.ProtoMember(5, Name = @"loaded_song_name")]
        [global::System.ComponentModel.DefaultValue("")]
        public string LoadedSongName { get; set; } = "";

        [global::ProtoBuf.ProtoMember(6, Name = @"player_ids")]
        public global::System.Collections.Generic.List<string> PlayerIds { get; set; } = new global::System.Collections.Generic.List<string>();

        [global::ProtoBuf.ProtoMember(7, Name = @"player_states")]
        public global::System.Collections.Generic.List<LiveRoomPlayerState> PlayerStates { get; set; } = new global::System.Collections.Generic.List<LiveRoomPlayerState>();

        [global::ProtoBuf.ProtoMember(8, Name = @"viewer_count")]
        public uint ViewerCount { get; set; }

        [global::ProtoBuf.ProtoMember(9, Name = @"viewers")]
        public global::System.Collections.Generic.List<LiveRoomViewerState> Viewers { get; set; } = new global::System.Collections.Generic.List<LiveRoomViewerState>();

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class LiveRoomPlayerState : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"player_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PlayerId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"play_state")]
        public LudusPlayState PlayState { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"download_state")]
        public LudusDownloadState DownloadState { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"ready_state")]
        public LudusReadyState ReadyState { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"is_bot")]
        public bool IsBot { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"error_message")]
        [global::System.ComponentModel.DefaultValue("")]
        public string ErrorMessage { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class LiveRoomViewerState : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"player_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PlayerId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"client_type")]
        public LudusClientType ClientType { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class LiveTournamentStreamSnapshot : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"tournament_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string TournamentId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"sequence")]
        public ulong Sequence { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"server_time_unix_ms")]
        public long ServerTimeUnixMs { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"rooms")]
        public global::System.Collections.Generic.List<LiveRoomStreamSnapshot> Rooms { get; set; } = new global::System.Collections.Generic.List<LiveRoomStreamSnapshot>();

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class LiveRoomStreamSnapshot : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"room")]
        public LiveMatchRoomState Room { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"replay_states")]
        public global::System.Collections.Generic.List<LiveRoomReplayState> ReplayStates { get; set; } = new global::System.Collections.Generic.List<LiveRoomReplayState>();

        [global::ProtoBuf.ProtoMember(3, Name = @"replay_packets")]
        public global::System.Collections.Generic.List<ReplayStreamPacket> ReplayPackets { get; set; } = new global::System.Collections.Generic.List<ReplayStreamPacket>();

        [global::ProtoBuf.ProtoMember(4, Name = @"live_edge_song_time_ms")]
        public long LiveEdgeSongTimeMs { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"playback_buffer")]
        public LivePlaybackBuffer PlaybackBuffer { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class LivePlaybackBuffer : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"policy")]
        public LivePlaybackPolicy Policy { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"recommended_delay_ms")]
        public uint RecommendedDelayMs { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"min_delay_ms")]
        public uint MinDelayMs { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"max_delay_ms")]
        public uint MaxDelayMs { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class LiveRoomReplayState : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"player_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PlayerId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"stream_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string StreamId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"sequence")]
        public ulong Sequence { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"song_time_ms")]
        public long SongTimeMs { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"server_time_unix_ms")]
        public long ServerTimeUnixMs { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"stream_state")]
        public ReplayStreamState StreamState { get; set; }

        [global::ProtoBuf.ProtoMember(7, Name = @"score")]
        public uint Score { get; set; }

        [global::ProtoBuf.ProtoMember(8, Name = @"accuracy")]
        public double Accuracy
        {
            get => __pbn__Accuracy.GetValueOrDefault();
            set => __pbn__Accuracy = value;
        }
        public bool ShouldSerializeAccuracy() => __pbn__Accuracy != null;
        public void ResetAccuracy() => __pbn__Accuracy = null;
        private double? __pbn__Accuracy;

        [global::ProtoBuf.ProtoMember(9, Name = @"combo")]
        public uint Combo
        {
            get => __pbn__Combo.GetValueOrDefault();
            set => __pbn__Combo = value;
        }
        public bool ShouldSerializeCombo() => __pbn__Combo != null;
        public void ResetCombo() => __pbn__Combo = null;
        private uint? __pbn__Combo;

        [global::ProtoBuf.ProtoMember(10, Name = @"notes_missed")]
        public uint NotesMissed { get; set; }

        [global::ProtoBuf.ProtoMember(11, Name = @"full_combo")]
        public bool FullCombo { get; set; }

        [global::ProtoBuf.ProtoMember(12, Name = @"completion")]
        public ReplayCompletion Completion { get; set; }

        [global::ProtoBuf.ProtoMember(13, Name = @"map_hash")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MapHash { get; set; } = "";

        [global::ProtoBuf.ProtoMember(14, Name = @"rank")]
        public uint Rank { get; set; }

        [global::ProtoBuf.ProtoMember(15, Name = @"paused")]
        public bool Paused { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public enum LivePlaybackPolicy
    {
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_PLAYBACK_POLICY_UNSPECIFIED")]
        LivePlaybackPolicyUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_PLAYBACK_POLICY_LOW_LATENCY")]
        LivePlaybackPolicyLowLatency = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_PLAYBACK_POLICY_SYNCED_ROOM")]
        LivePlaybackPolicySyncedRoom = 2,
    }

}

#pragma warning restore CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
#endregion
