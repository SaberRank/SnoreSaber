





#region Designer generated code
#pragma warning disable CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
namespace SnoreSaber.Live.V1
{

    [global::ProtoBuf.ProtoContract()]
    public partial class ServerCommand : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"command_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string CommandId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"type")]
        public LudusCommandType Type { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(4, Name = @"target_player_ids")]
        public global::System.Collections.Generic.List<string> TargetPlayerIds { get; set; } = new global::System.Collections.Generic.List<string>();

        [global::ProtoBuf.ProtoMember(5, Name = @"song")]
        public LiveSongCommand Song { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"prompt_title")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PromptTitle { get; set; } = "";

        [global::ProtoBuf.ProtoMember(7, Name = @"prompt_message")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PromptMessage { get; set; } = "";

        [global::ProtoBuf.ProtoMember(8, Name = @"prompt_primary_text")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PromptPrimaryText { get; set; } = "";

        [global::ProtoBuf.ProtoMember(9, Name = @"prompt_secondary_text")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PromptSecondaryText { get; set; } = "";

        [global::ProtoBuf.ProtoMember(10, Name = @"prompt_timeout_ms")]
        public uint PromptTimeoutMs { get; set; }

        [global::ProtoBuf.ProtoMember(11, Name = @"with_sync")]
        public bool WithSync { get; set; }

        [global::ProtoBuf.ProtoMember(12, Name = @"start_time_unix_ms")]
        public long StartTimeUnixMs { get; set; }

        [global::ProtoBuf.ProtoMember(13, Name = @"countdown_ms")]
        public uint CountdownMs { get; set; }

        [global::ProtoBuf.ProtoMember(14, Name = @"force_start")]
        public bool ForceStart { get; set; }

        [global::ProtoBuf.ProtoMember(20, Name = @"payload_json")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PayloadJson { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class PromptResponse : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"command_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string CommandId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"player_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PlayerId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(4, Name = @"accepted")]
        public bool Accepted { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"responded_at_unix_ms")]
        public long RespondedAtUnixMs { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"prompt_message")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PromptMessage { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class LiveSongCommand : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"hash")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Hash { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"difficulty")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Difficulty { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"characteristic")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Characteristic { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public enum LudusCommandType
    {
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_COMMAND_TYPE_UNSPECIFIED")]
        LudusCommandTypeUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_COMMAND_TYPE_LOAD_SONG")]
        LudusCommandTypeLoadSong = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_COMMAND_TYPE_START_MAP")]
        LudusCommandTypeStartMap = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_COMMAND_TYPE_RETURN_TO_MENU")]
        LudusCommandTypeReturnToMenu = 3,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_COMMAND_TYPE_PROMPT")]
        LudusCommandTypePrompt = 4,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_COMMAND_TYPE_SYNC_PLAYERS")]
        LudusCommandTypeSyncPlayers = 10,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_COMMAND_TYPE_CREATE_ROOM")]
        LudusCommandTypeCreateRoom = 11,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_COMMAND_TYPE_CLOSE_ROOM")]
        LudusCommandTypeCloseRoom = 12,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_COMMAND_TYPE_BOTTIFY")]
        LudusCommandTypeBottify = 13,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_COMMAND_TYPE_FOLLOW_ROOM")]
        LudusCommandTypeFollowRoom = 20,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_COMMAND_TYPE_FOLLOW_PLAYER")]
        LudusCommandTypeFollowPlayer = 21,
    }

}

#pragma warning restore CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
#endregion
