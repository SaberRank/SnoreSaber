





#region Designer generated code
#pragma warning disable CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
namespace SnoreSaber.Live.V1
{

    [global::ProtoBuf.ProtoContract()]
    public partial class LiveMod : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Id { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"version")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Version { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public enum LivePlayerPlatform
    {
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_PLAYER_PLATFORM_UNSPECIFIED")]
        LivePlayerPlatformUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_PLAYER_PLATFORM_STEAM")]
        LivePlayerPlatformSteam = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_PLAYER_PLATFORM_OCULUS")]
        LivePlayerPlatformOculus = 2,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum LudusClientType
    {
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_CLIENT_TYPE_UNSPECIFIED")]
        LudusClientTypeUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_CLIENT_TYPE_PLAYER")]
        LudusClientTypePlayer = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_CLIENT_TYPE_SPECTATOR")]
        LudusClientTypeSpectator = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_CLIENT_TYPE_ORGANIZER")]
        LudusClientTypeOrganizer = 3,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_CLIENT_TYPE_WEBSITE")]
        LudusClientTypeWebsite = 4,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_CLIENT_TYPE_CASTER")]
        LudusClientTypeCaster = 5,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum LudusPlayState
    {
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_PLAY_STATE_UNSPECIFIED")]
        LudusPlayStateUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_PLAY_STATE_IN_MENUS")]
        LudusPlayStateInMenus = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_PLAY_STATE_PAUSED")]
        LudusPlayStatePaused = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_PLAY_STATE_IN_GAME")]
        LudusPlayStateInGame = 3,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum LudusReadyState
    {
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_READY_STATE_UNSPECIFIED")]
        LudusReadyStateUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_READY_STATE_NOT_READY")]
        LudusReadyStateNotReady = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_READY_STATE_READY")]
        LudusReadyStateReady = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_READY_STATE_AFK")]
        LudusReadyStateAfk = 3,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum LudusDownloadState
    {
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_DOWNLOAD_STATE_UNSPECIFIED")]
        LudusDownloadStateUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_DOWNLOAD_STATE_NONE")]
        LudusDownloadStateNone = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_DOWNLOAD_STATE_DOWNLOADING")]
        LudusDownloadStateDownloading = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_DOWNLOAD_STATE_DOWNLOADED")]
        LudusDownloadStateDownloaded = 3,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_DOWNLOAD_STATE_ERROR")]
        LudusDownloadStateError = 4,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum LiveScoreCompletion
    {
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_SCORE_COMPLETION_UNSPECIFIED")]
        LiveScoreCompletionUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_SCORE_COMPLETION_PASSED")]
        LiveScoreCompletionPassed = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_SCORE_COMPLETION_FAILED")]
        LiveScoreCompletionFailed = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_SCORE_COMPLETION_QUIT")]
        LiveScoreCompletionQuit = 3,
    }

}

#pragma warning restore CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
#endregion
