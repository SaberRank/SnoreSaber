





#region Designer generated code
#pragma warning disable CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
namespace SnoreSaber.Live.V1
{

    [global::ProtoBuf.ProtoContract()]
    public partial class SetRoomContextRequest : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"room_context")]
        public LudusRoomContextType RoomContext { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"tournament_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string TournamentId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"mods")]
        public global::System.Collections.Generic.List<LiveMod> Mods { get; set; } = new global::System.Collections.Generic.List<LiveMod>();

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class RoomContextUpdated : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"room_context")]
        public LudusRoomContextType RoomContext { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"tournament_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string TournamentId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"current_match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string CurrentMatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(4, Name = @"client_type")]
        public LudusClientType ClientType { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class JoinRoomRequest : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"room_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string RoomId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"mods")]
        public global::System.Collections.Generic.List<LiveMod> Mods { get; set; } = new global::System.Collections.Generic.List<LiveMod>();

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class LeaveRoomRequest : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class FollowRoomRequest : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"player_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PlayerId { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public enum LudusRoomContextType
    {
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_ROOM_CONTEXT_TYPE_UNSPECIFIED")]
        LudusRoomContextTypeUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_ROOM_CONTEXT_TYPE_CORE")]
        LudusRoomContextTypeCore = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_ROOM_CONTEXT_TYPE_PUBLIC_PRESENCE")]
        LudusRoomContextTypePublicPresence = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"LUDUS_ROOM_CONTEXT_TYPE_TOURNAMENT")]
        LudusRoomContextTypeTournament = 3,
    }

}

#pragma warning restore CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
#endregion
