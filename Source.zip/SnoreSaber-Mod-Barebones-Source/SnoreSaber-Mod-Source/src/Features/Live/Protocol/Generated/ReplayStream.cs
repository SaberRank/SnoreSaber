





#region Designer generated code
#pragma warning disable CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
namespace SnoreSaber.Live.V1
{

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayStreamPacket : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"stream_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string StreamId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"connection_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string ConnectionId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"player_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PlayerId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(4, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(10, Name = @"start")]
        public ReplayStreamStart Start
        {
            get => __pbn__body.Is(10) ? ((ReplayStreamStart)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(10, value);
        }
        public bool ShouldSerializeStart() => __pbn__body.Is(10);
        public void ResetStart() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 10);

        private global::ProtoBuf.DiscriminatedUnionObject __pbn__body;

        [global::ProtoBuf.ProtoMember(11, Name = @"chunk")]
        public ReplayChunk Chunk
        {
            get => __pbn__body.Is(11) ? ((ReplayChunk)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(11, value);
        }
        public bool ShouldSerializeChunk() => __pbn__body.Is(11);
        public void ResetChunk() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 11);

        [global::ProtoBuf.ProtoMember(12, Name = @"checkpoint")]
        public ReplayCheckpoint Checkpoint
        {
            get => __pbn__body.Is(12) ? ((ReplayCheckpoint)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(12, value);
        }
        public bool ShouldSerializeCheckpoint() => __pbn__body.Is(12);
        public void ResetCheckpoint() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 12);

        [global::ProtoBuf.ProtoMember(13, Name = @"end")]
        public ReplayStreamEnd End
        {
            get => __pbn__body.Is(13) ? ((ReplayStreamEnd)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(13, value);
        }
        public bool ShouldSerializeEnd() => __pbn__body.Is(13);
        public void ResetEnd() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 13);

        [global::ProtoBuf.ProtoMember(14, Name = @"failure")]
        public ReplayStreamFailure Failure
        {
            get => __pbn__body.Is(14) ? ((ReplayStreamFailure)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(14, value);
        }
        public bool ShouldSerializeFailure() => __pbn__body.Is(14);
        public void ResetFailure() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 14);

        [global::ProtoBuf.ProtoMember(15, Name = @"resume_request")]
        public ReplayResumeRequest ResumeRequest
        {
            get => __pbn__body.Is(15) ? ((ReplayResumeRequest)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(15, value);
        }
        public bool ShouldSerializeResumeRequest() => __pbn__body.Is(15);
        public void ResetResumeRequest() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 15);

        [global::ProtoBuf.ProtoMember(16, Name = @"resume_response")]
        public ReplayResumeResponse ResumeResponse
        {
            get => __pbn__body.Is(16) ? ((ReplayResumeResponse)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(16, value);
        }
        public bool ShouldSerializeResumeResponse() => __pbn__body.Is(16);
        public void ResetResumeResponse() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 16);

        [global::ProtoBuf.ProtoMember(17, Name = @"ack")]
        public ReplayAck Ack
        {
            get => __pbn__body.Is(17) ? ((ReplayAck)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(17, value);
        }
        public bool ShouldSerializeAck() => __pbn__body.Is(17);
        public void ResetAck() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 17);

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayStreamStart : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"protocol_version")]
        public uint ProtocolVersion { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"player")]
        public PlayerIdentity Player { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"beatmap")]
        public BeatmapIdentity Beatmap { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"payload_format")]
        public ReplayPayloadFormat PayloadFormat { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"payload_format_version")]
        public uint PayloadFormatVersion { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"payload_compression")]
        public ReplayCompression PayloadCompression { get; set; }

        [global::ProtoBuf.ProtoMember(7, Name = @"recommended_chunk_size_bytes")]
        public uint RecommendedChunkSizeBytes { get; set; }

        [global::ProtoBuf.ProtoMember(8, Name = @"max_chunk_size_bytes")]
        public uint MaxChunkSizeBytes { get; set; }

        [global::ProtoBuf.ProtoMember(9, Name = @"client_start_time_unix_ms")]
        public long ClientStartTimeUnixMs { get; set; }

        [global::ProtoBuf.ProtoMember(10, Name = @"server_start_time_unix_ms")]
        public long ServerStartTimeUnixMs { get; set; }

        [global::ProtoBuf.ProtoMember(11, Name = @"game_session_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string GameSessionId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(12, Name = @"features", IsPacked = true)]
        public global::System.Collections.Generic.List<ReplayFeature> Features { get; set; } = new global::System.Collections.Generic.List<ReplayFeature>();

        [global::ProtoBuf.ProtoMember(13, Name = @"replay_metadata")]
        public StreamReplayMetadata ReplayMetadata { get; set; }

        [global::ProtoBuf.ProtoMember(14, Name = @"replay_extensions")]
        public global::System.Collections.Generic.List<ReplayExtension> ReplayExtensions { get; set; } = new global::System.Collections.Generic.List<ReplayExtension>();

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class PlayerIdentity : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"player_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PlayerId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"platform")]
        public ReplayPlatform Platform { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"game_version")]
        [global::System.ComponentModel.DefaultValue("")]
        public string GameVersion { get; set; } = "";

        [global::ProtoBuf.ProtoMember(4, Name = @"client_version")]
        [global::System.ComponentModel.DefaultValue("")]
        public string ClientVersion { get; set; } = "";

        [global::ProtoBuf.ProtoMember(5, Name = @"replay_mod_version")]
        [global::System.ComponentModel.DefaultValue("")]
        public string ReplayModVersion { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class BeatmapIdentity : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"map_hash")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MapHash { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"level_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string LevelId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"difficulty")]
        public int Difficulty { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"difficulty_name")]
        [global::System.ComponentModel.DefaultValue("")]
        public string DifficultyName { get; set; } = "";

        [global::ProtoBuf.ProtoMember(5, Name = @"characteristic")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Characteristic { get; set; } = "";

        [global::ProtoBuf.ProtoMember(6, Name = @"leaderboard_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string LeaderboardId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(7, Name = @"modifiers")]
        public global::System.Collections.Generic.List<string> Modifiers { get; set; } = new global::System.Collections.Generic.List<string>();

        [global::ProtoBuf.ProtoMember(8, Name = @"max_score")]
        public uint MaxScore { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayCursor : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"sequence")]
        public ulong Sequence { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"song_time_ms")]
        public long SongTimeMs { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"server_time_unix_ms")]
        public long ServerTimeUnixMs { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"client_time_unix_ms")]
        public long ClientTimeUnixMs { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayChunk : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"cursor")]
        public ReplayCursor Cursor { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"events")]
        public StreamReplayEventBatch Events { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"cumulative_event_counts")]
        public ReplayEventCounts CumulativeEventCounts { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"replay_extensions")]
        public global::System.Collections.Generic.List<ReplayExtension> ReplayExtensions { get; set; } = new global::System.Collections.Generic.List<ReplayExtension>();

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayCheckpoint : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"cursor")]
        public ReplayCursor Cursor { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"kind")]
        public ReplayCheckpointKind Kind { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"snapshot")]
        public StreamReplaySnapshot Snapshot { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"last_contiguous_sequence")]
        public ulong LastContiguousSequence { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayStreamEnd : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"cursor")]
        public ReplayCursor Cursor { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"completion")]
        public ReplayCompletion Completion { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"score")]
        public ReplayScoreSummary Score { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"chunk_count")]
        public ulong ChunkCount { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"cumulative_event_counts")]
        public ReplayEventCounts CumulativeEventCounts { get; set; }

        [global::ProtoBuf.ProtoMember(7, Name = @"stream_sha256")]
        public byte[] StreamSha256 { get; set; }

        [global::ProtoBuf.ProtoMember(8, Name = @"replay_extensions")]
        public global::System.Collections.Generic.List<ReplayExtension> ReplayExtensions { get; set; } = new global::System.Collections.Generic.List<ReplayExtension>();

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayStreamFailure : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"last_committed_cursor")]
        public ReplayCursor LastCommittedCursor { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"reason")]
        public ReplayFailureReason Reason { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"state")]
        public ReplayStreamState State { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"message")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Message { get; set; } = "";

        [global::ProtoBuf.ProtoMember(5, Name = @"can_resume")]
        public bool CanResume { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"resume_window_seconds")]
        public uint ResumeWindowSeconds { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayResumeRequest : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"last_received_sequence")]
        public ulong LastReceivedSequence { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"previous_connection_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PreviousConnectionId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"last_packet_sha256")]
        public byte[] LastPacketSha256 { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayResumeResponse : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"status")]
        public ReplayResumeStatus Status { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"next_sequence")]
        public ulong NextSequence { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"highest_buffered_sequence")]
        public ulong HighestBufferedSequence { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"checkpoint_required")]
        public bool CheckpointRequired { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"message")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Message { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayAck : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"highest_contiguous_sequence")]
        public ulong HighestContiguousSequence { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"missing_sequences", IsPacked = true)]
        public global::System.Collections.Generic.List<ulong> MissingSequences { get; set; } = new global::System.Collections.Generic.List<ulong>();

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class StreamReplayMetadata : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"replay_version")]
        [global::System.ComponentModel.DefaultValue("")]
        public string ReplayVersion { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"level_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string LevelId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"difficulty")]
        public int Difficulty { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"characteristic")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Characteristic { get; set; } = "";

        [global::ProtoBuf.ProtoMember(5, Name = @"environment")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Environment { get; set; } = "";

        [global::ProtoBuf.ProtoMember(6, Name = @"modifiers")]
        public global::System.Collections.Generic.List<string> Modifiers { get; set; } = new global::System.Collections.Generic.List<string>();

        [global::ProtoBuf.ProtoMember(7, Name = @"note_spawn_offset")]
        public float NoteSpawnOffset { get; set; }

        [global::ProtoBuf.ProtoMember(8, Name = @"left_handed")]
        public bool LeftHanded { get; set; }

        [global::ProtoBuf.ProtoMember(9, Name = @"initial_height")]
        public float InitialHeight { get; set; }

        [global::ProtoBuf.ProtoMember(10, Name = @"room_rotation")]
        public float RoomRotation { get; set; }

        [global::ProtoBuf.ProtoMember(11, Name = @"room_center")]
        public ReplayVector3 RoomCenter { get; set; }

        [global::ProtoBuf.ProtoMember(12, Name = @"fail_time_seconds")]
        public float FailTimeSeconds { get; set; }

        [global::ProtoBuf.ProtoMember(13, Name = @"game_version")]
        [global::System.ComponentModel.DefaultValue("")]
        public string GameVersion { get; set; } = "";

        [global::ProtoBuf.ProtoMember(14, Name = @"plugin_version")]
        [global::System.ComponentModel.DefaultValue("")]
        public string PluginVersion { get; set; } = "";

        [global::ProtoBuf.ProtoMember(15, Name = @"platform")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Platform { get; set; } = "";

        [global::ProtoBuf.ProtoMember(16, Name = @"song_speed")]
        public float SongSpeed { get; set; }

        [global::ProtoBuf.ProtoMember(17, Name = @"jump_distance")]
        public float JumpDistance { get; set; }

        [global::ProtoBuf.ProtoMember(18, Name = @"left_saber_color")]
        public ReplayColor LeftSaberColor { get; set; }

        [global::ProtoBuf.ProtoMember(19, Name = @"right_saber_color")]
        public ReplayColor RightSaberColor { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class StreamReplayEventBatch : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"pose_frames")]
        public global::System.Collections.Generic.List<ReplayPoseFrame> PoseFrames { get; set; } = new global::System.Collections.Generic.List<ReplayPoseFrame>();

        [global::ProtoBuf.ProtoMember(2, Name = @"height_events")]
        public global::System.Collections.Generic.List<ReplayHeightEvent> HeightEvents { get; set; } = new global::System.Collections.Generic.List<ReplayHeightEvent>();

        [global::ProtoBuf.ProtoMember(3, Name = @"note_events")]
        public global::System.Collections.Generic.List<ReplayNoteEvent> NoteEvents { get; set; } = new global::System.Collections.Generic.List<ReplayNoteEvent>();

        [global::ProtoBuf.ProtoMember(4, Name = @"score_events")]
        public global::System.Collections.Generic.List<ReplayScoreEvent> ScoreEvents { get; set; } = new global::System.Collections.Generic.List<ReplayScoreEvent>();

        [global::ProtoBuf.ProtoMember(5, Name = @"combo_events")]
        public global::System.Collections.Generic.List<ReplayComboEvent> ComboEvents { get; set; } = new global::System.Collections.Generic.List<ReplayComboEvent>();

        [global::ProtoBuf.ProtoMember(6, Name = @"multiplier_events")]
        public global::System.Collections.Generic.List<ReplayMultiplierEvent> MultiplierEvents { get; set; } = new global::System.Collections.Generic.List<ReplayMultiplierEvent>();

        [global::ProtoBuf.ProtoMember(7, Name = @"energy_events")]
        public global::System.Collections.Generic.List<ReplayEnergyEvent> EnergyEvents { get; set; } = new global::System.Collections.Generic.List<ReplayEnergyEvent>();

        [global::ProtoBuf.ProtoMember(8, Name = @"min_time_seconds")]
        public float MinTimeSeconds { get; set; }

        [global::ProtoBuf.ProtoMember(9, Name = @"max_time_seconds")]
        public float MaxTimeSeconds { get; set; }

        [global::ProtoBuf.ProtoMember(10, Name = @"pause_events")]
        public global::System.Collections.Generic.List<ReplayPauseEvent> PauseEvents { get; set; } = new global::System.Collections.Generic.List<ReplayPauseEvent>();

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class StreamReplaySnapshot : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"replay_metadata")]
        public StreamReplayMetadata ReplayMetadata { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"latest_pose")]
        public ReplayPoseFrame LatestPose { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"latest_height")]
        public ReplayHeightEvent LatestHeight { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"latest_score")]
        public ReplayScoreEvent LatestScore { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"latest_combo")]
        public ReplayComboEvent LatestCombo { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"latest_multiplier")]
        public ReplayMultiplierEvent LatestMultiplier { get; set; }

        [global::ProtoBuf.ProtoMember(7, Name = @"latest_energy")]
        public ReplayEnergyEvent LatestEnergy { get; set; }

        [global::ProtoBuf.ProtoMember(8, Name = @"cumulative_event_counts")]
        public ReplayEventCounts CumulativeEventCounts { get; set; }

        [global::ProtoBuf.ProtoMember(9, Name = @"replay_extensions")]
        public global::System.Collections.Generic.List<ReplayExtension> ReplayExtensions { get; set; } = new global::System.Collections.Generic.List<ReplayExtension>();

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayExtension : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Id { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"version")]
        public uint Version { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"payload")]
        public byte[] Payload { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayEventCounts : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"pose_frames")]
        public ulong PoseFrames { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"height_events")]
        public ulong HeightEvents { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"note_events")]
        public ulong NoteEvents { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"score_events")]
        public ulong ScoreEvents { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"combo_events")]
        public ulong ComboEvents { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"multiplier_events")]
        public ulong MultiplierEvents { get; set; }

        [global::ProtoBuf.ProtoMember(7, Name = @"energy_events")]
        public ulong EnergyEvents { get; set; }

        [global::ProtoBuf.ProtoMember(8, Name = @"pause_events")]
        public ulong PauseEvents { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayPoseFrame : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"head")]
        public ReplayPose Head { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"left")]
        public ReplayPose Left { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"right")]
        public ReplayPose Right { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"fps")]
        public int Fps { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"time_seconds")]
        public float TimeSeconds { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayPose : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"position")]
        public ReplayVector3 Position { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"rotation")]
        public ReplayQuaternion Rotation { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayVector3 : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"x")]
        public float X { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"y")]
        public float Y { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"z")]
        public float Z { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayQuaternion : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"x")]
        public float X { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"y")]
        public float Y { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"z")]
        public float Z { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"w")]
        public float W { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayColor : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"r")]
        public float R { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"g")]
        public float G { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"b")]
        public float B { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"a")]
        public float A { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayHeightEvent : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"height")]
        public float Height { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"time_seconds")]
        public float TimeSeconds { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayScoreEvent : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"score")]
        public int Score { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"time_seconds")]
        public float TimeSeconds { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"immediate_max_possible_score")]
        public int ImmediateMaxPossibleScore
        {
            get => __pbn__ImmediateMaxPossibleScore.GetValueOrDefault();
            set => __pbn__ImmediateMaxPossibleScore = value;
        }
        public bool ShouldSerializeImmediateMaxPossibleScore() => __pbn__ImmediateMaxPossibleScore != null;
        public void ResetImmediateMaxPossibleScore() => __pbn__ImmediateMaxPossibleScore = null;
        private int? __pbn__ImmediateMaxPossibleScore;

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayComboEvent : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"combo")]
        public int Combo { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"time_seconds")]
        public float TimeSeconds { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayMultiplierEvent : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"multiplier")]
        public int Multiplier { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"next_multiplier_progress")]
        public float NextMultiplierProgress { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"time_seconds")]
        public float TimeSeconds { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayEnergyEvent : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"energy")]
        public float Energy { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"time_seconds")]
        public float TimeSeconds { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayPauseEvent : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"paused")]
        public bool Paused { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"time_seconds")]
        public float TimeSeconds { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"client_time_unix_ms")]
        public long ClientTimeUnixMs { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayNoteEvent : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"note_id")]
        public ReplayNoteId NoteId { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"event_type")]
        public ReplayNoteEventType EventType { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"cut_point")]
        public ReplayVector3 CutPoint { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"cut_normal")]
        public ReplayVector3 CutNormal { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"saber_direction")]
        public ReplayVector3 SaberDirection { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"saber_type")]
        public int SaberType { get; set; }

        [global::ProtoBuf.ProtoMember(7, Name = @"direction_ok")]
        public bool DirectionOk { get; set; }

        [global::ProtoBuf.ProtoMember(8, Name = @"saber_speed")]
        public float SaberSpeed { get; set; }

        [global::ProtoBuf.ProtoMember(9, Name = @"cut_angle")]
        public float CutAngle { get; set; }

        [global::ProtoBuf.ProtoMember(10, Name = @"cut_distance_to_center")]
        public float CutDistanceToCenter { get; set; }

        [global::ProtoBuf.ProtoMember(11, Name = @"cut_direction_deviation")]
        public float CutDirectionDeviation { get; set; }

        [global::ProtoBuf.ProtoMember(12, Name = @"before_cut_rating")]
        public float BeforeCutRating { get; set; }

        [global::ProtoBuf.ProtoMember(13, Name = @"after_cut_rating")]
        public float AfterCutRating { get; set; }

        [global::ProtoBuf.ProtoMember(14, Name = @"time_seconds")]
        public float TimeSeconds { get; set; }

        [global::ProtoBuf.ProtoMember(15, Name = @"unity_timescale")]
        public float UnityTimescale { get; set; }

        [global::ProtoBuf.ProtoMember(16, Name = @"time_sync_timescale")]
        public float TimeSyncTimescale { get; set; }

        [global::ProtoBuf.ProtoMember(17, Name = @"time_deviation")]
        public float TimeDeviation
        {
            get => __pbn__TimeDeviation.GetValueOrDefault();
            set => __pbn__TimeDeviation = value;
        }
        public bool ShouldSerializeTimeDeviation() => __pbn__TimeDeviation != null;
        public void ResetTimeDeviation() => __pbn__TimeDeviation = null;
        private float? __pbn__TimeDeviation;

        [global::ProtoBuf.ProtoMember(18, Name = @"world_rotation")]
        public ReplayQuaternion WorldRotation { get; set; }

        [global::ProtoBuf.ProtoMember(19, Name = @"inverse_world_rotation")]
        public ReplayQuaternion InverseWorldRotation { get; set; }

        [global::ProtoBuf.ProtoMember(20, Name = @"note_rotation")]
        public ReplayQuaternion NoteRotation { get; set; }

        [global::ProtoBuf.ProtoMember(21, Name = @"note_position")]
        public ReplayVector3 NotePosition { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayNoteId : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"time_seconds")]
        public float TimeSeconds { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"line_layer")]
        public int LineLayer { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"line_index")]
        public int LineIndex { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"color_type")]
        public int ColorType { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"cut_direction")]
        public int CutDirection { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"gameplay_type")]
        public int GameplayType
        {
            get => __pbn__GameplayType.GetValueOrDefault();
            set => __pbn__GameplayType = value;
        }
        public bool ShouldSerializeGameplayType() => __pbn__GameplayType != null;
        public void ResetGameplayType() => __pbn__GameplayType = null;
        private int? __pbn__GameplayType;

        [global::ProtoBuf.ProtoMember(7, Name = @"scoring_type")]
        public int ScoringType
        {
            get => __pbn__ScoringType.GetValueOrDefault();
            set => __pbn__ScoringType = value;
        }
        public bool ShouldSerializeScoringType() => __pbn__ScoringType != null;
        public void ResetScoringType() => __pbn__ScoringType = null;
        private int? __pbn__ScoringType;

        [global::ProtoBuf.ProtoMember(8, Name = @"cut_direction_angle_offset")]
        public float CutDirectionAngleOffset
        {
            get => __pbn__CutDirectionAngleOffset.GetValueOrDefault();
            set => __pbn__CutDirectionAngleOffset = value;
        }
        public bool ShouldSerializeCutDirectionAngleOffset() => __pbn__CutDirectionAngleOffset != null;
        public void ResetCutDirectionAngleOffset() => __pbn__CutDirectionAngleOffset = null;
        private float? __pbn__CutDirectionAngleOffset;

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class ReplayScoreSummary : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"score")]
        public uint Score { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"modified_score")]
        public uint ModifiedScore { get; set; }

        [global::ProtoBuf.ProtoMember(3, Name = @"max_score")]
        public uint MaxScore { get; set; }

        [global::ProtoBuf.ProtoMember(4, Name = @"accuracy")]
        public double Accuracy { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"combo")]
        public uint Combo { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"max_combo")]
        public uint MaxCombo { get; set; }

        [global::ProtoBuf.ProtoMember(7, Name = @"full_combo")]
        public bool FullCombo { get; set; }

        [global::ProtoBuf.ProtoMember(8, Name = @"good_cuts")]
        public uint GoodCuts { get; set; }

        [global::ProtoBuf.ProtoMember(9, Name = @"bad_cuts")]
        public uint BadCuts { get; set; }

        [global::ProtoBuf.ProtoMember(10, Name = @"missed_notes")]
        public uint MissedNotes { get; set; }

        [global::ProtoBuf.ProtoMember(11, Name = @"bomb_hits")]
        public uint BombHits { get; set; }

        [global::ProtoBuf.ProtoMember(12, Name = @"wall_hits")]
        public uint WallHits { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public enum ReplayPayloadFormat
    {
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_PAYLOAD_FORMAT_UNSPECIFIED")]
        ReplayPayloadFormatUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_PAYLOAD_FORMAT_SCORESABER_STREAM_V1")]
        ReplayPayloadFormatScoresaberStreamV1 = 1,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum ReplayCompression
    {
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_COMPRESSION_UNSPECIFIED")]
        ReplayCompressionUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_COMPRESSION_NONE")]
        ReplayCompressionNone = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_COMPRESSION_ZSTD")]
        ReplayCompressionZstd = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_COMPRESSION_LZ4")]
        ReplayCompressionLz4 = 3,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum ReplayFeature
    {
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FEATURE_UNSPECIFIED")]
        ReplayFeatureUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FEATURE_CHECKPOINTS")]
        ReplayFeatureCheckpoints = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FEATURE_RESUME")]
        ReplayFeatureResume = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FEATURE_SPECTATOR_CATCHUP")]
        ReplayFeatureSpectatorCatchup = 3,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum ReplayPlatform
    {
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_PLATFORM_UNSPECIFIED")]
        ReplayPlatformUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_PLATFORM_STEAM")]
        ReplayPlatformSteam = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_PLATFORM_OCULUS_PC")]
        ReplayPlatformOculusPc = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_PLATFORM_META_QUEST")]
        ReplayPlatformMetaQuest = 3,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_PLATFORM_DEV")]
        ReplayPlatformDev = 4,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum ReplayCheckpointKind
    {
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_CHECKPOINT_KIND_UNSPECIFIED")]
        ReplayCheckpointKindUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_CHECKPOINT_KIND_KEYFRAME")]
        ReplayCheckpointKindKeyframe = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_CHECKPOINT_KIND_STATE_SNAPSHOT")]
        ReplayCheckpointKindStateSnapshot = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_CHECKPOINT_KIND_SERVER_WATERMARK")]
        ReplayCheckpointKindServerWatermark = 3,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum ReplayNoteEventType
    {
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_NOTE_EVENT_TYPE_UNSPECIFIED")]
        ReplayNoteEventTypeUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_NOTE_EVENT_TYPE_GOOD_CUT")]
        ReplayNoteEventTypeGoodCut = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_NOTE_EVENT_TYPE_BAD_CUT")]
        ReplayNoteEventTypeBadCut = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_NOTE_EVENT_TYPE_MISS")]
        ReplayNoteEventTypeMiss = 3,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_NOTE_EVENT_TYPE_BOMB")]
        ReplayNoteEventTypeBomb = 4,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum ReplayCompletion
    {
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_COMPLETION_UNSPECIFIED")]
        ReplayCompletionUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_COMPLETION_PASSED")]
        ReplayCompletionPassed = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_COMPLETION_FAILED")]
        ReplayCompletionFailed = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_COMPLETION_QUIT")]
        ReplayCompletionQuit = 3,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_COMPLETION_ABORTED")]
        ReplayCompletionAborted = 4,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum ReplayStreamState
    {
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_STREAM_STATE_UNSPECIFIED")]
        ReplayStreamStateUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_STREAM_STATE_STARTING")]
        ReplayStreamStateStarting = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_STREAM_STATE_STREAMING")]
        ReplayStreamStateStreaming = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_STREAM_STATE_DISCONNECTED")]
        ReplayStreamStateDisconnected = 3,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_STREAM_STATE_RESUMING")]
        ReplayStreamStateResuming = 4,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_STREAM_STATE_ENDED")]
        ReplayStreamStateEnded = 5,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_STREAM_STATE_FAILED")]
        ReplayStreamStateFailed = 6,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum ReplayFailureReason
    {
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_UNSPECIFIED")]
        ReplayFailureReasonUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_CLIENT_DISCONNECTED")]
        ReplayFailureReasonClientDisconnected = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_SERVER_DISCONNECTED")]
        ReplayFailureReasonServerDisconnected = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_AUTH_EXPIRED")]
        ReplayFailureReasonAuthExpired = 3,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_OUT_OF_ORDER")]
        ReplayFailureReasonOutOfOrder = 4,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_DUPLICATE_SEQUENCE")]
        ReplayFailureReasonDuplicateSequence = 5,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_MISSING_SEQUENCE")]
        ReplayFailureReasonMissingSequence = 6,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_PAYLOAD_TOO_LARGE")]
        ReplayFailureReasonPayloadTooLarge = 7,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_STREAM_EXPIRED")]
        ReplayFailureReasonStreamExpired = 8,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_VALIDATION_FAILED")]
        ReplayFailureReasonValidationFailed = 9,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_STREAM_FINALIZATION_FAILED")]
        ReplayFailureReasonStreamFinalizationFailed = 10,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_FAILURE_REASON_INTERNAL_ERROR")]
        ReplayFailureReasonInternalError = 11,
    }

    [global::ProtoBuf.ProtoContract()]
    public enum ReplayResumeStatus
    {
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_RESUME_STATUS_UNSPECIFIED")]
        ReplayResumeStatusUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_RESUME_STATUS_ACCEPTED")]
        ReplayResumeStatusAccepted = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_RESUME_STATUS_NEED_CHECKPOINT")]
        ReplayResumeStatusNeedCheckpoint = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_RESUME_STATUS_TOO_OLD")]
        ReplayResumeStatusTooOld = 3,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_RESUME_STATUS_STREAM_CLOSED")]
        ReplayResumeStatusStreamClosed = 4,
        [global::ProtoBuf.ProtoEnum(Name = @"REPLAY_RESUME_STATUS_REJECTED")]
        ReplayResumeStatusRejected = 5,
    }

}

#pragma warning restore CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
#endregion
