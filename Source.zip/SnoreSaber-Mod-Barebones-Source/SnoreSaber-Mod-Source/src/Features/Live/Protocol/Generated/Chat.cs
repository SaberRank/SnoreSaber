





#region Designer generated code
#pragma warning disable CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
namespace SnoreSaber.Live.V1
{

    [global::ProtoBuf.ProtoContract()]
    public partial class LiveChatMessageRequest : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"text")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Text { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"sender_display_name")]
        [global::System.ComponentModel.DefaultValue("")]
        public string SenderDisplayName { get; set; } = "";

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class LiveChatMessage : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"message_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MessageId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"tournament_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string TournamentId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(4, Name = @"room_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string RoomId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(5, Name = @"sender_connection_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string SenderConnectionId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(6, Name = @"sender_player_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string SenderPlayerId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(7, Name = @"sender_display_name")]
        [global::System.ComponentModel.DefaultValue("")]
        public string SenderDisplayName { get; set; } = "";

        [global::ProtoBuf.ProtoMember(8, Name = @"sender_client_type")]
        public LudusClientType SenderClientType { get; set; }

        [global::ProtoBuf.ProtoMember(9, Name = @"kind")]
        public LiveChatMessageKind Kind { get; set; }

        [global::ProtoBuf.ProtoMember(10, Name = @"text")]
        [global::System.ComponentModel.DefaultValue("")]
        public string Text { get; set; } = "";

        [global::ProtoBuf.ProtoMember(11, Name = @"created_at_unix_ms")]
        public long CreatedAtUnixMs { get; set; }

        [global::ProtoBuf.ProtoMember(12, Name = @"room_sequence")]
        public ulong RoomSequence { get; set; }

    }

    [global::ProtoBuf.ProtoContract()]
    public partial class LiveChatSnapshot : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"tournament_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string TournamentId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(2, Name = @"match_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MatchId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"messages")]
        public global::System.Collections.Generic.List<LiveChatMessage> Messages { get; set; } = new global::System.Collections.Generic.List<LiveChatMessage>();

    }

    [global::ProtoBuf.ProtoContract()]
    public enum LiveChatMessageKind
    {
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_CHAT_MESSAGE_KIND_UNSPECIFIED")]
        LiveChatMessageKindUnspecified = 0,
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_CHAT_MESSAGE_KIND_CHAT")]
        LiveChatMessageKindChat = 1,
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_CHAT_MESSAGE_KIND_LOG")]
        LiveChatMessageKindLog = 2,
        [global::ProtoBuf.ProtoEnum(Name = @"LIVE_CHAT_MESSAGE_KIND_SYSTEM")]
        LiveChatMessageKindSystem = 3,
    }

}

#pragma warning restore CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
#endregion
