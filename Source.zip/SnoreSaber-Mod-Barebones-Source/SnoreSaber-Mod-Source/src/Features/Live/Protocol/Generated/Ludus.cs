





#region Designer generated code
#pragma warning disable CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
namespace SnoreSaber.Live.V1
{

    [global::ProtoBuf.ProtoContract()]
    public partial class LudusEnvelope : global::ProtoBuf.IExtensible
    {
        private global::ProtoBuf.IExtension __pbn__extensionData;
        global::ProtoBuf.IExtension global::ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
            => global::ProtoBuf.Extensible.GetExtensionObject(ref __pbn__extensionData, createIfMissing);

        [global::ProtoBuf.ProtoMember(1, Name = @"protocol_version")]
        public uint ProtocolVersion { get; set; }

        [global::ProtoBuf.ProtoMember(2, Name = @"message_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string MessageId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(3, Name = @"connection_id")]
        [global::System.ComponentModel.DefaultValue("")]
        public string ConnectionId { get; set; } = "";

        [global::ProtoBuf.ProtoMember(4, Name = @"sequence")]
        public ulong Sequence { get; set; }

        [global::ProtoBuf.ProtoMember(5, Name = @"client_time_unix_ms")]
        public long ClientTimeUnixMs { get; set; }

        [global::ProtoBuf.ProtoMember(6, Name = @"server_time_unix_ms")]
        public long ServerTimeUnixMs { get; set; }

        [global::ProtoBuf.ProtoMember(10, Name = @"connect_request")]
        public ConnectRequest ConnectRequest
        {
            get => __pbn__body.Is(10) ? ((ConnectRequest)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(10, value);
        }
        public bool ShouldSerializeConnectRequest() => __pbn__body.Is(10);
        public void ResetConnectRequest() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 10);

        private global::ProtoBuf.DiscriminatedUnionObject __pbn__body;

        [global::ProtoBuf.ProtoMember(11, Name = @"connect_accepted")]
        public ConnectAccepted ConnectAccepted
        {
            get => __pbn__body.Is(11) ? ((ConnectAccepted)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(11, value);
        }
        public bool ShouldSerializeConnectAccepted() => __pbn__body.Is(11);
        public void ResetConnectAccepted() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 11);

        [global::ProtoBuf.ProtoMember(12, Name = @"heartbeat")]
        public Heartbeat Heartbeat
        {
            get => __pbn__body.Is(12) ? ((Heartbeat)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(12, value);
        }
        public bool ShouldSerializeHeartbeat() => __pbn__body.Is(12);
        public void ResetHeartbeat() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 12);

        [global::ProtoBuf.ProtoMember(13, Name = @"heartbeat_ack")]
        public HeartbeatAck HeartbeatAck
        {
            get => __pbn__body.Is(13) ? ((HeartbeatAck)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(13, value);
        }
        public bool ShouldSerializeHeartbeatAck() => __pbn__body.Is(13);
        public void ResetHeartbeatAck() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 13);

        [global::ProtoBuf.ProtoMember(14, Name = @"error")]
        public ErrorResponse Error
        {
            get => __pbn__body.Is(14) ? ((ErrorResponse)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(14, value);
        }
        public bool ShouldSerializeError() => __pbn__body.Is(14);
        public void ResetError() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 14);

        [global::ProtoBuf.ProtoMember(15, Name = @"reconnect_requested")]
        public ReconnectRequested ReconnectRequested
        {
            get => __pbn__body.Is(15) ? ((ReconnectRequested)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(15, value);
        }
        public bool ShouldSerializeReconnectRequested() => __pbn__body.Is(15);
        public void ResetReconnectRequested() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 15);

        [global::ProtoBuf.ProtoMember(16, Name = @"set_client_type_request")]
        public SetClientTypeRequest SetClientTypeRequest
        {
            get => __pbn__body.Is(16) ? ((SetClientTypeRequest)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(16, value);
        }
        public bool ShouldSerializeSetClientTypeRequest() => __pbn__body.Is(16);
        public void ResetSetClientTypeRequest() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 16);

        [global::ProtoBuf.ProtoMember(20, Name = @"set_room_context_request")]
        public SetRoomContextRequest SetRoomContextRequest
        {
            get => __pbn__body.Is(20) ? ((SetRoomContextRequest)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(20, value);
        }
        public bool ShouldSerializeSetRoomContextRequest() => __pbn__body.Is(20);
        public void ResetSetRoomContextRequest() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 20);

        [global::ProtoBuf.ProtoMember(21, Name = @"join_room_request")]
        public JoinRoomRequest JoinRoomRequest
        {
            get => __pbn__body.Is(21) ? ((JoinRoomRequest)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(21, value);
        }
        public bool ShouldSerializeJoinRoomRequest() => __pbn__body.Is(21);
        public void ResetJoinRoomRequest() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 21);

        [global::ProtoBuf.ProtoMember(22, Name = @"leave_room_request")]
        public LeaveRoomRequest LeaveRoomRequest
        {
            get => __pbn__body.Is(22) ? ((LeaveRoomRequest)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(22, value);
        }
        public bool ShouldSerializeLeaveRoomRequest() => __pbn__body.Is(22);
        public void ResetLeaveRoomRequest() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 22);

        [global::ProtoBuf.ProtoMember(23, Name = @"follow_room_request")]
        public FollowRoomRequest FollowRoomRequest
        {
            get => __pbn__body.Is(23) ? ((FollowRoomRequest)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(23, value);
        }
        public bool ShouldSerializeFollowRoomRequest() => __pbn__body.Is(23);
        public void ResetFollowRoomRequest() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 23);

        [global::ProtoBuf.ProtoMember(24, Name = @"room_context_updated")]
        public RoomContextUpdated RoomContextUpdated
        {
            get => __pbn__body.Is(24) ? ((RoomContextUpdated)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(24, value);
        }
        public bool ShouldSerializeRoomContextUpdated() => __pbn__body.Is(24);
        public void ResetRoomContextUpdated() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 24);

        [global::ProtoBuf.ProtoMember(30, Name = @"presence_update")]
        public PresenceUpdate PresenceUpdate
        {
            get => __pbn__body.Is(30) ? ((PresenceUpdate)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(30, value);
        }
        public bool ShouldSerializePresenceUpdate() => __pbn__body.Is(30);
        public void ResetPresenceUpdate() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 30);

        [global::ProtoBuf.ProtoMember(31, Name = @"download_state_update")]
        public DownloadStateUpdate DownloadStateUpdate
        {
            get => __pbn__body.Is(31) ? ((DownloadStateUpdate)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(31, value);
        }
        public bool ShouldSerializeDownloadStateUpdate() => __pbn__body.Is(31);
        public void ResetDownloadStateUpdate() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 31);

        [global::ProtoBuf.ProtoMember(32, Name = @"ready_state_update")]
        public ReadyStateUpdate ReadyStateUpdate
        {
            get => __pbn__body.Is(32) ? ((ReadyStateUpdate)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(32, value);
        }
        public bool ShouldSerializeReadyStateUpdate() => __pbn__body.Is(32);
        public void ResetReadyStateUpdate() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 32);

        [global::ProtoBuf.ProtoMember(40, Name = @"replay_packet")]
        public ReplayStreamPacket ReplayPacket
        {
            get => __pbn__body.Is(40) ? ((ReplayStreamPacket)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(40, value);
        }
        public bool ShouldSerializeReplayPacket() => __pbn__body.Is(40);
        public void ResetReplayPacket() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 40);

        [global::ProtoBuf.ProtoMember(50, Name = @"prompt_response")]
        public PromptResponse PromptResponse
        {
            get => __pbn__body.Is(50) ? ((PromptResponse)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(50, value);
        }
        public bool ShouldSerializePromptResponse() => __pbn__body.Is(50);
        public void ResetPromptResponse() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 50);

        [global::ProtoBuf.ProtoMember(60, Name = @"server_command")]
        public ServerCommand ServerCommand
        {
            get => __pbn__body.Is(60) ? ((ServerCommand)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(60, value);
        }
        public bool ShouldSerializeServerCommand() => __pbn__body.Is(60);
        public void ResetServerCommand() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 60);

        [global::ProtoBuf.ProtoMember(61, Name = @"room_snapshot")]
        public RoomSnapshot RoomSnapshot
        {
            get => __pbn__body.Is(61) ? ((RoomSnapshot)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(61, value);
        }
        public bool ShouldSerializeRoomSnapshot() => __pbn__body.Is(61);
        public void ResetRoomSnapshot() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 61);

        [global::ProtoBuf.ProtoMember(62, Name = @"stream_snapshot")]
        public LiveTournamentStreamSnapshot StreamSnapshot
        {
            get => __pbn__body.Is(62) ? ((LiveTournamentStreamSnapshot)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(62, value);
        }
        public bool ShouldSerializeStreamSnapshot() => __pbn__body.Is(62);
        public void ResetStreamSnapshot() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 62);

        [global::ProtoBuf.ProtoMember(70, Name = @"chat_message_request")]
        public LiveChatMessageRequest ChatMessageRequest
        {
            get => __pbn__body.Is(70) ? ((LiveChatMessageRequest)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(70, value);
        }
        public bool ShouldSerializeChatMessageRequest() => __pbn__body.Is(70);
        public void ResetChatMessageRequest() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 70);

        [global::ProtoBuf.ProtoMember(71, Name = @"chat_message")]
        public LiveChatMessage ChatMessage
        {
            get => __pbn__body.Is(71) ? ((LiveChatMessage)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(71, value);
        }
        public bool ShouldSerializeChatMessage() => __pbn__body.Is(71);
        public void ResetChatMessage() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 71);

        [global::ProtoBuf.ProtoMember(72, Name = @"chat_snapshot")]
        public LiveChatSnapshot ChatSnapshot
        {
            get => __pbn__body.Is(72) ? ((LiveChatSnapshot)__pbn__body.Object) : default;
            set => __pbn__body = new global::ProtoBuf.DiscriminatedUnionObject(72, value);
        }
        public bool ShouldSerializeChatSnapshot() => __pbn__body.Is(72);
        public void ResetChatSnapshot() => global::ProtoBuf.DiscriminatedUnionObject.Reset(ref __pbn__body, 72);

    }

}

#pragma warning restore CS0612, CS0618, CS1591, CS3021, CS8981, IDE0079, IDE1006, RCS1036, RCS1057, RCS1085, RCS1192
#endregion
