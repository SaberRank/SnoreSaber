
namespace SnoreSaber.Core.ReplaySystem.HarmonyPatches {
    internal static class PatchHandleHMDUnmounted {
        internal static bool Prefix() => !SnoreSaber.Features.Replays.ReplayStateRegistry.IsPlaybackEnabled;
    }
}
