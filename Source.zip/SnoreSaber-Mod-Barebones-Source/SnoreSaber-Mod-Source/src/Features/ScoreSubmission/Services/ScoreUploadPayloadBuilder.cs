using Newtonsoft.Json;
using SnoreSaber.Core;
using SnoreSaber.Core.Gameplay;
using SnoreSaber.Features.Players.Domain;
using SnoreSaber.Features.ScoreSubmission.Domain;
using System;

namespace SnoreSaber.Features.ScoreSubmission.Services {

    internal class ScoreUploadPayloadBuilder {
        private const string UploadSecret = "REPLACE_WITH_PRIVATE_SERVER_SECRET";
        private readonly SnoreSaberRuntimeInfo _runtimeInfo;

        public ScoreUploadPayloadBuilder(SnoreSaberRuntimeInfo runtimeInfo) {
            _runtimeInfo = runtimeInfo;
        }

        internal ScoreUploadPayload Build(BeatmapLevel beatmapLevel, BeatmapKey beatmapKey, LevelCompletionResults results, LocalPlayerInfo playerInfo, string authenticatedPlayerId, float playOutcomeTime, SnoreSaberPlayOutcome? playOutcomeOverride) {
            SnoreSaberUploadData scoreData = SnoreSaberUploadData.Create(beatmapLevel, beatmapKey, results, playerInfo, _runtimeInfo.UploadVersionHash, playOutcomeTime, playOutcomeOverride);
            if (!string.IsNullOrWhiteSpace(authenticatedPlayerId)) scoreData.PlayerId = authenticatedPlayerId;
            string serializedScore = JsonConvert.SerializeObject(scoreData);
            return new ScoreUploadPayload {
                ScoreData = scoreData,
                
                
                
                EncryptedScoreData = serializedScore
            };
        }

    }

    internal class ScoreUploadPayload {
        internal SnoreSaberUploadData ScoreData { get; set; }
        internal string EncryptedScoreData { get; set; } = string.Empty;
    }
}
