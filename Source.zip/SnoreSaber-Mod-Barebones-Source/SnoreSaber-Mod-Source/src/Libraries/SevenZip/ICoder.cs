

using System;

namespace SevenZip
{
	
	
	
	class DataErrorException : ApplicationException
	{
		public DataErrorException(): base("Data Error") { }
	}

	
	
	
	class InvalidParamException : ApplicationException
	{
		public InvalidParamException(): base("Invalid Parameter") { }
	}

	public interface ICodeProgress
	{
		
		
		
		
		
		
		
		
		
		void SetProgress(Int64 inSize, Int64 outSize);
	};

	public interface ICoder
	{
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		void Code(System.IO.Stream inStream, System.IO.Stream outStream,
			Int64 inSize, Int64 outSize, ICodeProgress progress);
	};

	

	
	
	
	public enum CoderPropID
	{
		
		
		
		DictionarySize = 0x400,
		
		
		
		UsedMemorySize,
		
		
		
		Order,
		
		
		
		PosStateBits = 0x440,
		
		
		
		LitContextBits,
		
		
		
		LitPosBits,
		
		
		
		NumFastBytes = 0x450,
		
		
		
		MatchFinder,
		
		
		
		NumPasses = 0x460,
		
		
		
		Algorithm = 0x470,
		
		
		
		MultiThread = 0x480,
		
		
		
		EndMarker = 0x490
	};


	public interface ISetCoderProperties
	{
		void SetCoderProperties(CoderPropID[] propIDs, object[] properties);
	};

	public interface IWriteCoderProperties
	{
		void WriteCoderProperties(System.IO.Stream outStream);
	}

	public interface ISetDecoderProperties
	{
		void SetDecoderProperties(byte[] properties);
	}
}
