using System;
using System.Linq;
using System.Reflection;

namespace SnoreSaber.Core {
    internal static class SnoreSaberEndpoints {
        private const string DefaultWebsiteBaseUrl = "https://snoresaber.vercel.app";
        private const string DefaultApiBaseUrl = "https://snoresaber.vercel.app";
        private const string DefaultCdnBaseUrl = "https://flagcdn.com/w80";
        private const string DefaultLudusUrl = "wss://snoresaber-ludus.vercel.app/v1/connect";

        internal static readonly string WebsiteBaseUrl = ConfiguredUrl("SnoreSaberWebsiteBaseUrl", DefaultWebsiteBaseUrl);
        internal static readonly string ApiBaseUrl = ConfiguredUrl("SnoreSaberApiBaseUrl", DefaultApiBaseUrl);
        internal static readonly string CdnBaseUrl = ConfiguredUrl("SnoreSaberCdnBaseUrl", DefaultCdnBaseUrl);
        internal static readonly string LudusUrl = ConfiguredUrl("SnoreSaberLudusUrl", DefaultLudusUrl);

        internal static string GlobalLeaderboard() {
            return $"{WebsiteBaseUrl}/global";
        }

        internal static string Leaderboard(int leaderboardId) {
            return $"{WebsiteBaseUrl}/leaderboard/{leaderboardId}";
        }

        internal static string Player(string playerId) {
            return $"{WebsiteBaseUrl}/u/{playerId}";
        }

        internal static string Flag(string country) {
            if (string.IsNullOrWhiteSpace(country)) {
                return string.Empty;
            }

            return $"{CdnBaseUrl}/{country.Trim().ToLowerInvariant()}.png";
        }

        
        
        internal static string ResolveImageUrl(string imageUrl) {
            if (string.IsNullOrWhiteSpace(imageUrl)) {
                return string.Empty;
            }

            imageUrl = imageUrl.Trim();
            if (imageUrl.StartsWith("//", StringComparison.Ordinal)) {
                return "https:" + imageUrl;
            }

            if (imageUrl.StartsWith("/", StringComparison.Ordinal)) {
                return WebsiteBaseUrl + imageUrl;
            }

            if (Uri.TryCreate(imageUrl, UriKind.Absolute, out Uri uri)) {
                if (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps) {
                    
                    if (uri.Host.EndsWith(".local", StringComparison.OrdinalIgnoreCase)) {
                        return WebsiteBaseUrl + uri.PathAndQuery + uri.Fragment;
                    }

                    return uri.AbsoluteUri;
                }

                return imageUrl;
            }

            return WebsiteBaseUrl + "/" + imageUrl.TrimStart('/');
        }

        private static string ConfiguredUrl(string key, string fallback) {
            string value = typeof(Plugin)
                .Assembly
                .GetCustomAttributes<AssemblyMetadataAttribute>()
                .FirstOrDefault(x => x.Key == key)
                ?.Value;

            return string.IsNullOrWhiteSpace(value) ? fallback : value.Trim().TrimEnd('/');
        }
    }
}
