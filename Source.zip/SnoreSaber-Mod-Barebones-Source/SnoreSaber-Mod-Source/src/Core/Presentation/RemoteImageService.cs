using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using SnoreSaber.Core;
using UnityEngine;
using UnityEngine.Networking;
using Zenject;

namespace SnoreSaber.Core.Presentation {

    internal class RemoteImageService : IDisposable {
        private const int MaxSpriteCacheSize = 150;

        private readonly Dictionary<string, Sprite> _cachedSprites = new Dictionary<string, Sprite>();
        private readonly Queue<string> _spriteCacheQueue = new Queue<string>();
        private ICoroutineStarter _coroutineStarter;

        [Inject]
        public void Init(ICoroutineStarter coroutineStarter) {
            _coroutineStarter = coroutineStarter;
        }

        internal void LoadSprite(string url, Action<Sprite> onSuccess, Action<string> onFailure, CancellationToken cancellationToken) {
            try {
                cancellationToken.ThrowIfCancellationRequested();
                url = SnoreSaberEndpoints.ResolveImageUrl(url);
                if (string.IsNullOrWhiteSpace(url)) {
                    onFailure?.Invoke("Image URL is empty");
                    return;
                }

                
                
                if (url.StartsWith("data:image/", StringComparison.OrdinalIgnoreCase)) {
                    if (_cachedSprites.TryGetValue(url, out Sprite dataSprite)) {
                        onSuccess?.Invoke(dataSprite);
                        return;
                    }

                    int comma = url.IndexOf(',');
                    if (comma < 0 || url.IndexOf(";base64", 0, comma, StringComparison.OrdinalIgnoreCase) < 0) {
                        onFailure?.Invoke("Unsupported image data URL");
                        return;
                    }

                    try {
                        byte[] bytes = Convert.FromBase64String(url.Substring(comma + 1));
                        var texture = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                        if (!texture.LoadImage(bytes, false)) {
                            UnityEngine.Object.Destroy(texture);
                            onFailure?.Invoke("Image data URL could not be decoded");
                            return;
                        }

                        var decodedSprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.one * 0.5f);
                        AddSpriteToCache(url, decodedSprite);
                        onSuccess?.Invoke(decodedSprite);
                    } catch (Exception ex) {
                        onFailure?.Invoke($"Invalid image data URL: {ex.Message}");
                    }
                    return;
                }

                if (_cachedSprites.TryGetValue(url, out Sprite sprite)) {
                    onSuccess?.Invoke(sprite);
                    return;
                }

                if (_coroutineStarter == null) {
                    onFailure?.Invoke("Coroutine starter unavailable");
                    return;
                }

                _coroutineStarter.StartCoroutine(GetSprite(url, onSuccess, onFailure, cancellationToken));
            } catch (OperationCanceledException) {
                onFailure?.Invoke("Cancelled");
            } finally {
                MaintainSpriteCache();
            }
        }

        private IEnumerator GetSprite(string url, Action<Sprite> onSuccess, Action<string> onFailure, CancellationToken cancellationToken) {
            
            
            if (url.StartsWith("data:image/", StringComparison.OrdinalIgnoreCase)) {
                int commaIndex = url.IndexOf(',');
                if (commaIndex < 0 || url.IndexOf(";base64", StringComparison.OrdinalIgnoreCase) < 0) {
                    onFailure?.Invoke("Image data URL is malformed or is not Base64");
                    yield break;
                }

                byte[] imageBytes;
                try {
                    imageBytes = Convert.FromBase64String(url.Substring(commaIndex + 1));
                } catch (FormatException) {
                    onFailure?.Invoke("Image data URL contains invalid Base64 data");
                    yield break;
                }

                if (cancellationToken.IsCancellationRequested) {
                    onFailure?.Invoke("Cancelled");
                    yield break;
                }

                var texture = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                if (!texture.LoadImage(imageBytes, false)) {
                    UnityEngine.Object.Destroy(texture);
                    onFailure?.Invoke("Base64 data URL did not contain a supported image");
                    yield break;
                }

                Sprite dataUrlSprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.one * 0.5f);
                AddSpriteToCache(url, dataUrlSprite);
                onSuccess?.Invoke(dataUrlSprite);
                yield break;
            }

            using (var request = new UnityWebRequest(url, UnityWebRequest.kHttpVerbGET)) {
                
                
                
                request.downloadHandler = new DownloadHandlerBuffer();
                request.disposeDownloadHandlerOnDispose = true;

                AsyncOperation operation = request.SendWebRequest();
                while (!operation.isDone) {
                    if (cancellationToken.IsCancellationRequested) {
                        request.Abort();
                        onFailure?.Invoke("Cancelled");
                        yield break;
                    }

                    yield return null;
                }

                if (cancellationToken.IsCancellationRequested) {
                    onFailure?.Invoke("Cancelled");
                    yield break;
                }

                if (request.IsProtocolError() || request.IsConnectionError()) {
                    onFailure?.Invoke($"HTTP {request.responseCode}: {request.error} ({url})");
                    yield break;
                }

                if (!string.IsNullOrEmpty(request.error)) {
                    onFailure?.Invoke($"{request.error} ({url})");
                    yield break;
                }

                byte[] imageBytes = request.downloadHandler.data;
                if (imageBytes == null || imageBytes.Length == 0) {
                    onFailure?.Invoke($"Image response was empty (HTTP {request.responseCode}, {url})");
                    yield break;
                }

                
                var texture = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                if (!texture.LoadImage(imageBytes, false)) {
                    UnityEngine.Object.Destroy(texture);
                    onFailure?.Invoke($"Response was not a supported image (HTTP {request.responseCode}, {url})");
                    yield break;
                }

                Sprite downloadedSprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.one * 0.5f);
                AddSpriteToCache(url, downloadedSprite);
                onSuccess?.Invoke(downloadedSprite);
            }
        }

        private void MaintainSpriteCache() {
            while (_cachedSprites.Count > MaxSpriteCacheSize) {
                string oldestUrl = _spriteCacheQueue.Dequeue();
                if (_cachedSprites.TryGetValue(oldestUrl, out Sprite sprite)) {
                    _cachedSprites.Remove(oldestUrl);
                    DestroySprite(sprite);
                }
            }
        }

        private void AddSpriteToCache(string url, Sprite sprite) {
            if (_cachedSprites.ContainsKey(url)) {
                DestroySprite(sprite);
                return;
            }

            _cachedSprites.Add(url, sprite);
            _spriteCacheQueue.Enqueue(url);
            MaintainSpriteCache();
        }

        public void Dispose() {
            foreach (Sprite sprite in _cachedSprites.Values) {
                DestroySprite(sprite);
            }

            _cachedSprites.Clear();
            _spriteCacheQueue.Clear();
        }

        private static void DestroySprite(Sprite sprite) {
            if (sprite == null) {
                return;
            }

            Texture2D texture = sprite.texture;
            UnityEngine.Object.Destroy(sprite);
            if (texture != null) {
                UnityEngine.Object.Destroy(texture);
            }
        }
    }
}
