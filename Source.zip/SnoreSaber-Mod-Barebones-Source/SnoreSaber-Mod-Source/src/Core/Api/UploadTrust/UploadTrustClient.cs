using SnoreSaber.Core.Api.Generated;
using System;

namespace SnoreSaber.Core.Api.UploadTrust {
    internal sealed class UploadTrustClient {
        private readonly SnoreSaberRuntimeInfo _runtimeInfo;
        private readonly UploadTrustBuildMetadata _buildMetadata;

        internal UploadTrustClient(SnoreSaberRuntimeInfo runtimeInfo)
            : this(runtimeInfo, UploadTrustBuildMetadata.FromAssembly(typeof(Plugin).Assembly)) {
        }

        internal UploadTrustClient(SnoreSaberRuntimeInfo runtimeInfo, UploadTrustBuildMetadata buildMetadata) {
            _runtimeInfo = runtimeInfo;
            _buildMetadata = buildMetadata;
        }

        internal void ApplyAuthMetadata(GameAuthenticateRequest request) {
            
            
        }

        internal UploadTrustSession CreateSession(GameAuthenticateResponse response) {
            
            
            return null;
        }
    }
}
